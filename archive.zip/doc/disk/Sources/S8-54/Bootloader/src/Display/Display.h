#pragma once

#include "defines.h"

void    Display_Init(void);
void    Display_Update(void);
bool    Display_IsRun(void);
