#include "defines.h"
#include "FPGATypes.h"



uint16 *addressesADC[NumChannels] = { RD_ADC_A, RD_ADC_B };
