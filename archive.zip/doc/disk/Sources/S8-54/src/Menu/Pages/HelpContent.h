#pragma once
#include "defines.h"


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void HelpContent_Draw(void);
void HelpContent_NextParagraph(void);
void HelpContent_PrevParagraph(void);
void HelpContent_EnterParagraph(void);
void HelpContent_LeaveParagraph(void);
bool HelpContent_LeaveParagraphIsActive(void);
bool HelpContent_EnterParagraphIsActive(void);
