#include "SettingsNew.h"


SettingsNew setNew;

void SettingsNew_Init(void)
{
    setNew.nrst_NumSmoothForRand = 0xffff;
}
