#pragma once
#include "defines.h"
#include "SettingsTypes.h"
#include "Utils/Measures.h"
#include "Menu/MenuItems.h"




extern SettingsNew setNew;

void SettingsNew_Init(void);
