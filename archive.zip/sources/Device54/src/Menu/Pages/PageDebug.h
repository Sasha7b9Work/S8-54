#pragma once


class PageDebug
{
public:
    static void OnChanged_ADC_Stretch_Mode(bool);
    static void OnChanged_DisplayOrientation(bool);
};
