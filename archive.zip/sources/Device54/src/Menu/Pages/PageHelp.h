#pragma once


class PageHelp
{
public:
    static const PageBase *pointer;
};
