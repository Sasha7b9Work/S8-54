// 2021/02/25 16:45:13 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once


struct PageService
{
    static void ResetSettings();
};
