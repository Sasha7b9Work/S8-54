#pragma once


class PageTrig
{
public:
    static void OnChanged_TrigMode(bool active);
};
