#pragma once


void Process_KEY(uint8 *buffer);
void Process_GOVERNOR(uint8 *buffer);
