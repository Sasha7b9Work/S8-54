#include "defines.h"
#include "common/Display/Font/Font_d.h"
#include "../../../../Panel/src/Display/Font/Font_p.h"


static int spacing = 1;


void PFont::SetSpacing(int s)
{
    spacing = s;
}
